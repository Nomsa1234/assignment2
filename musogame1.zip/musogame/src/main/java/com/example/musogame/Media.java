package com.example.musogame;

public class Media {
    public Media(String toString) {
    }
}
