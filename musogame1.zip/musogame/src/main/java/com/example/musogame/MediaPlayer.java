package com.example.musogame;

public class MediaPlayer {
    public static final Object INDEFINITE =0 ;

    public MediaPlayer(Media media) {
    }

    public void setAutoPlay(boolean b) {
    }

    public void stop() {
    }

    public void setCycleCount(Object indefinite) {
    }
}
