package com.example.musogame;

import javafx.scene.Node;

public class MediaView extends Node {
    public MediaView(MediaPlayer mediaPlayer) {
    }

    @Override
    public Node getStyleableNode() {
        return super.getStyleableNode();
    }

    public void setFitWidth(int i) {
    }

    public void setFitHeight(int i) {
    }
}
